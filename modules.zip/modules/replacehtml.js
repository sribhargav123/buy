module.exports=function(template,product){
    let output=template.replace('{{%IMAGE%}}',product.productImage)
    output=output.replace('{{%NAME%}}',product.name)
    output= output.replace('{{%MOdelNAME%}}',product.modeName)
    output=output.replace('{{%Number%}}',product.modelNumber)
    output=output.replace('{{%Size%}}',product.size)
    output=output.replace('{{%Camera%}}',product.camera)
    output=output.replace('{{%PRICE%}}',product.price)
    output=output.replace('{{%COLOR%}}',product.color)
    output=output.replace('{{%id%}}',product.id)
    output=output.replace('{{%ROM%}}',product.ROM)
    output=output.replace('{{%desc%}}',product.Description)
    return output;
}